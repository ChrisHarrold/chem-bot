Deployment commands

bluemix api https://api.w3ibm.bluemix.net
bluemix login  -o NA_ESA -s dev -sso
bluemix app push DMESARecruiting
